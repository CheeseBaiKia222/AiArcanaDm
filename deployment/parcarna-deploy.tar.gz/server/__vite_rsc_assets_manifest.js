export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-Djvp9PZn.js\")",
  "clientReferenceDeps": {
    "9276801271d6": {
      "js": [
        "/_next/static/chunks/index-Djvp9PZn.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "0b874ad30386": {
      "js": [
        "/_next/static/chunks/index-Djvp9PZn.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "593f344dc510": {
      "js": [
        "/_next/static/chunks/index-Djvp9PZn.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "bad85346fc72": {
      "js": [
        "/_next/static/chunks/index-Djvp9PZn.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "15c18cfaeeff": {
      "js": [
        "/_next/static/chunks/layout-segment-context-BuU3ZR5m.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-Djvp9PZn.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "8c0f216c4604": {
      "js": [
        "/_next/static/chunks/index-Djvp9PZn.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "89c3cac48cb5": {
      "js": [
        "/_next/static/chunks/streamed-icons-DNogeH_Z.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-Djvp9PZn.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.DtAJTfub.css"
      ]
    }
  }
}