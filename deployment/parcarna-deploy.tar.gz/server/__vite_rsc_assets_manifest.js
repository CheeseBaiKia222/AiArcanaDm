export default {
  "bootstrapScriptContent": "import(\"/_next/static/chunks/index-C49ElJCd.js\")",
  "clientReferenceDeps": {
    "63e94e0166b5": {
      "js": [
        "/_next/static/chunks/index-C49ElJCd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "109d574796ea": {
      "js": [
        "/_next/static/chunks/index-C49ElJCd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "b1e71b04f18c": {
      "js": [
        "/_next/static/chunks/index-C49ElJCd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "f578a96473e1": {
      "js": [
        "/_next/static/chunks/index-C49ElJCd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "20596afcda50": {
      "js": [
        "/_next/static/chunks/layout-segment-context-COaUYPRR.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/index-C49ElJCd.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "7bff861649f9": {
      "js": [
        "/_next/static/chunks/index-C49ElJCd.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js"
      ],
      "css": []
    },
    "0d1291f49014": {
      "js": [
        "/_next/static/chunks/streamed-icons-DNogeH_Z.js",
        "/_next/static/chunks/rolldown-runtime-C60lm6uB.js",
        "/_next/static/chunks/framework-D_rUT4EX.js",
        "/_next/static/chunks/index-C49ElJCd.js"
      ],
      "css": []
    }
  },
  "serverResources": {
    "platform/sites/app/layout.tsx": {
      "js": [],
      "css": [
        "/_next/static/css/index.D3OueepW.css"
      ]
    }
  }
}